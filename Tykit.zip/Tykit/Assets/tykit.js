//** 2024 Typecho Theme Development Framework ©️ Copyright By Tomoriゞ */
const printLogo = () => {console.log("\n%c %s %c %s %c %s\n","color: #fff; background: #34495e; padding:5px 0;","基于Tykit框架","background: #fadfa3; padding:5px 0;","https://www.tykit.icu","color:#fff;background: #d6293e; padding:5px 0;","@Zirx_ ");};
printLogo();
